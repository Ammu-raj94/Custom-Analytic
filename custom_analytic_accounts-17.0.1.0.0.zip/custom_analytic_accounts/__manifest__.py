# -*- coding: utf-8 -*-
{
    'name': 'Custom Analytic Accounts',
    'version': '17.0.1.0.0',
    'depends': ['account_accountant', 'sale_management', 'stock'],
    'data': [
        'security/ir.model.access.csv',
        'data/analytic_account_data.xml',
        'views/season_master_views.xml',
        'views/customer_type_master_views.xml',
        'views/product_product_views.xml',
        'views/product_template_views.xml',
        'views/res_partner_views.xml',
        'views/stock_valuation_layer.xml',
    ],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': False,
}
