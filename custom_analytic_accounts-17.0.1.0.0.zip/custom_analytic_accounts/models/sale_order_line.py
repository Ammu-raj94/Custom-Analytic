# -*- coding: utf-8 -*-
from odoo import api, models


class SaleOrderLine(models.Model):
    """inherited the sale order line model for updating analytic account"""
    _inherit = 'sale.order.line'

    @api.onchange('product_id', 'product_tmpl_id')
    def _onchange_product_id(self):
        """"""
        for line in self:
            product_account = self.env['account.analytic.account'].search(
                ['|', ('name', '=', line.product_id.season_master_id.season), (
                'name', '=', line.product_template_id.season_master_id.season),
                 (
                     'plan_id', '=', self.env.ref(
                         'custom_analytic_accounts.analytic_plan_season').id)])
            partner_account = self.env['account.analytic.account'].search(
                [('name', '=',
                  line.order_id.partner_id.customer_master_id.customer_type), (
                     'plan_id', '=', self.env.ref(
                         'custom_analytic_accounts.analytic_plan_customer_type').id)])
            line.analytic_distribution = {
                f"{product_account.id}, {partner_account.id}": 100}
