# -*- coding: utf-8 -*-
from odoo import fields, models


class StockValuationLayer(models.Model):
    """inherited the stock_valuation layer for map the analytic distribution"""
    _inherit = 'stock.valuation.layer'

    analytic_precision = fields.Integer(
        store=False,
        default=lambda self: self.env['decimal.precision'].precision_get(
            "Percentage Analytic"),
    )
    analytic_distribution = fields.Json(
        'Analytic Distribution',
        readonly=True, store=True)
