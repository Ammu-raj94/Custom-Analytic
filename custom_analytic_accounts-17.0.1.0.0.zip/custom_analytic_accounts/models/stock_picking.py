# -*- coding: utf-8 -*-
from odoo import models


class StockPicking(models.Model):
    """Inherited stock picking for updating the corresponding analytic
    accounts to the stock valuation layer"""
    _inherit = 'stock.picking'

    def button_validate(self):
        res = super().button_validate()
        for moves in self.move_ids:
            for layers in moves.stock_valuation_layer_ids:
                layers.analytic_distribution = layers.stock_move_id.sale_line_id.analytic_distribution
        return res
