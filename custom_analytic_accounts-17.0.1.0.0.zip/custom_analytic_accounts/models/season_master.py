# -*- coding: utf-8 -*-
from odoo import api, fields, models


class SeasonMaster(models.Model):
    """Model create records will create analytic account under Season plan"""
    _name = 'season.master'
    _description = 'Season Master'
    _rec_name = 'season'

    season = fields.Char(string='Season', required=True)
    _sql_constraints = [
        ('season', 'UNIQUE(season)',
         'The Season Master must be unique')]

    def create_account(self, season_name):
        self.env['account.analytic.account'].create({
            'name': season_name,
            'plan_id': self.env.ref(
                'custom_analytic_accounts.analytic_plan_season').id,
        })

    @api.model_create_multi
    def create(self, vals):
        seasons = super().create(vals)
        for season in seasons:
            name = str(season.season)
            season.create_account(name)
        return seasons
