# -*- coding: utf-8 -*-
from odoo import fields, models


class ProductProduct(models.Model):
    """inherited the product model for adding season master"""
    _inherit = 'product.product'

    season_master_id = fields.Many2one('season.master', string='Season Master')
