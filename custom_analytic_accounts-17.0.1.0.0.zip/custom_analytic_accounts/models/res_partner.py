# -*- coding: utf-8 -*-
from odoo import fields, models


class ResPartner(models.Model):
    """inherited the partner model for adding customer type master"""
    _inherit = 'res.partner'

    customer_master_id = fields.Many2one('customer.type.master',
                                         string='Customer Type Master')
