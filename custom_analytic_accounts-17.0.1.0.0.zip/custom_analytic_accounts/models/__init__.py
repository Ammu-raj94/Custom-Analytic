# -*- coding: utf-8 -*-
from . import season_master
from . import customer_type_master
from . import product_product
from . import product_template
from . import res_partner
from . import sale_order_line
from . import stock_valuation_layer
from . import stock_picking
