# -*- coding: utf-8 -*-
from odoo import api, fields, models


class CustomerTypeMaster(models.Model):
    """Model create records will create analytic accounts under
    Customer Type plan."""
    _name = 'customer.type.master'
    _description = 'Customer Type Master'
    _rec_name = 'customer_type'

    customer_type = fields.Char(string='Customer Type Master', required=True)
    _sql_constraints = [
        ('customer_type', 'UNIQUE(customer_type)',
         'The Customer Type must be unique')]

    def create_account(self, customer_type):
        self.env['account.analytic.account'].create({
            'name': customer_type,
            'plan_id': self.env.ref(
                'custom_analytic_accounts.analytic_plan_customer_type').id,
        })

    @api.model_create_multi
    def create(self, vals):
        customer_types = super().create(vals)
        for types in customer_types:
            customer_type = str(types.customer_type)
            types.create_account(customer_type)
        return customer_types
